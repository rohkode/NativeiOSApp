package com.example.samplenativeandroid;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.clevertap.android.pushtemplates.PushTemplateNotificationHandler;
import com.clevertap.android.sdk.BaseCallbackManager;
import com.clevertap.android.sdk.CleverTapAPI;
import com.clevertap.android.sdk.Constants;
import com.clevertap.android.sdk.PushPermissionResponseListener;
import com.clevertap.android.sdk.inapp.CTLocalInApp;
import com.clevertap.android.sdk.interfaces.NotificationHandler;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity{
   /* public CleverTapAPI cleverTapAPI;
    public JSONObject jsonObject;
    public CleverTapAPI CleverTapSingleton;
    public Context ctx;
    public BaseCallbackManager cleverTapInstance;*/

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CleverTapAPI.setDebugLevel(3);
        CleverTapAPI clevertapDefaultInstance = CleverTapAPI.getDefaultInstance(getApplicationContext());
        //cleverTapAPI.setLocation(location); //android.location.Location
        String obj = new String();
        Location xyz = new Location(obj);
        clevertapDefaultInstance.setLocation(xyz);
        clevertapDefaultInstance.enableDeviceNetworkInfoReporting(true);


        CleverTapAPI.createNotificationChannel(getApplicationContext(), "got", "Game of Thrones", "Game Of Thrones", NotificationManager.IMPORTANCE_MAX, true, "gameofthrones.mp3");
        /*CleverTapSingleton.getDefaultInstance(ctx).suspendInAppNotifications();
        CleverTapSingleton.getDefaultInstance(ctx).discardInAppNotifications();
        CleverTapSingleton.getDefaultInstance(ctx).resumeInAppNotifications();

        clevertapDefaultInstance.promptForPushPermission(true);
        clevertapDefaultInstance.isPushPermissionGranted();
        clevertapDefaultInstance.promptPushPrimer(jsonObject);*/

        //Code for Login Data
        EditText editIdentity = findViewById(R.id.editIdentity);
        EditText editName = findViewById(R.id.editName);
        EditText editEmail = findViewById(R.id.editEmail);
        EditText editPhone = findViewById(R.id.editPhone);

        //Code for Event Push Data
        EditText edEName = findViewById(R.id.edEName);
        EditText edPname = findViewById(R.id.edPname);
        EditText edPcat = findViewById(R.id.edPcat);

        //Code for Button push
        Button btLogin = findViewById(R.id.btLogin);
        Button btProfile = findViewById(R.id.btProfile);
        Button btEvent = findViewById(R.id.btEvent);
        Button btEventPush = findViewById(R.id.btEventPush);
        Button btCharged = findViewById(R.id.btCharged);
        Button btPrimer = findViewById(R.id.btPrimer);

        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String identity = editIdentity.getText().toString();
                String name = editName.getText().toString();
                String email = editEmail.getText().toString();
                String phone = editPhone.getText().toString();


                Toast.makeText(MainActivity.this, "Hey there! Login is triggered.", Toast.LENGTH_SHORT).show();
                //Log.d("Clevertap", "onClick: "+
                // );

                // each of the below mentioned fields are optional
                HashMap<String, Object> profileUpdate = new HashMap<String, Object>();
                profileUpdate.put("Name", name);    // String
                profileUpdate.put("Identity", identity);      // String or number
                profileUpdate.put("Email", email); // Email address of the user
                profileUpdate.put("Phone", phone);   // Phone (with the country code, starting with +)
                profileUpdate.put("Gender", "M");             // Can be either M or F
                profileUpdate.put("DOB", new Date());         // Date of Birth. Set the Date object to the appropriate value first
                // optional fields. controls whether the user will be sent email, push etc.
                profileUpdate.put("MSG-email", true);        // Disable email notifications
                profileUpdate.put("MSG-push", true);          // Enable push notifications
                profileUpdate.put("MSG-sms", true);          // Disable SMS notifications
                profileUpdate.put("MSG-whatsapp", true);      // Enable WhatsApp notifications
                ArrayList<String> stuff = new ArrayList<String>();
                stuff.add("Bag");
                stuff.add("Shoes");
                profileUpdate.put("MyStuff", stuff);                      //ArrayList of Strings

                clevertapDefaultInstance.onUserLogin(profileUpdate);

            }
        });

        btProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String, Object> profileUpdate = new HashMap<String, Object>();
                ArrayList<String> stuff = new ArrayList<String>();
                stuff.add("Jeans");
                stuff.add("Tshirt");
                profileUpdate.put("MyStuff", stuff); //ArrayList of Strings
                clevertapDefaultInstance.pushProfile(profileUpdate);
                Toast.makeText(MainActivity.this, "Profile Push Is Triggered.", Toast.LENGTH_SHORT).show();
            }
        });

        //Product viewed event without properties
        btEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clevertapDefaultInstance.pushEvent("Product viewed");
                Toast.makeText(MainActivity.this, "An Event Is Pushed", Toast.LENGTH_SHORT).show();
            }
        });

        //Category view event with properties
        btEventPush.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String cname = edEName.getText().toString();
                String ctitle = edPname.getText().toString();
                String citems = edPcat.getText().toString();

                Toast.makeText(MainActivity.this, "Category Viewed event is triggered.", Toast.LENGTH_SHORT).show();
                clevertapDefaultInstance.pushEvent("Category Viewed");
                HashMap<String, Object> prodViewedAction = new HashMap<String, Object>();
                prodViewedAction.put("Category Name", cname);
                prodViewedAction.put("Product Title", ctitle);
                prodViewedAction.put("Total Items", citems);

                clevertapDefaultInstance.pushEvent("Category Viewed", prodViewedAction);

            }
        });

        //Charged event with array data type - special event
        btCharged.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                HashMap<String, Object> chargeDetails = new HashMap<String, Object>();
                chargeDetails.put("Amount", 300);
                chargeDetails.put("Payment Mode", "Credit card");
                chargeDetails.put("Charged ID", 24052013);

                HashMap<String, Object> item1 = new HashMap<String, Object>();
                item1.put("Product category", "books");
                item1.put("Book name", "The Millionaire next door");
                item1.put("Quantity", 1);

                HashMap<String, Object> item2 = new HashMap<String, Object>();
                item2.put("Product category", "books");
                item2.put("Book name", "Achieving inner zen");
                item2.put("Quantity", 1);

                HashMap<String, Object> item3 = new HashMap<String, Object>();
                item3.put("Product category", "books");
                item3.put("Book name", "Chuck it, let's do it");
                item3.put("Quantity", 5);

                ArrayList<HashMap<String, Object>> items = new ArrayList<HashMap<String, Object>>();
                items.add(item1);
                items.add(item2);
                items.add(item3);

                try {
                    clevertapDefaultInstance.pushChargedEvent(chargeDetails, items);
                } catch (Exception e) {
                    // You have to specify the first parameter to push()
                    // as CleverTapAPI.CHARGED_EVENT
                }
                Toast.makeText(MainActivity.this, "Charged Event has been successfully triggered", Toast.LENGTH_SHORT).show();
            }
        });

        btPrimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject jsonObject = CTLocalInApp.builder()
                        .setInAppType(CTLocalInApp.InAppType.HALF_INTERSTITIAL)
                        .setTitleText("Get Notified")
                        .setMessageText("Please enable notifications on your device to use Push Notifications.")
                        .followDeviceOrientation(true)
                        .setPositiveBtnText("Allow")
                        .setNegativeBtnText("Cancel")
                        .setBackgroundColor("WHITE")
                        .setBtnBorderColor("BLUE")
                        .setTitleTextColor("BLUE")
                        .setMessageTextColor("BLACK")
                        .setBtnTextColor("WHITE")
                        .setImageUrl("https://icons.iconarchive.com/icons/treetog/junior/64/camera-icon.png")
                        .setBtnBackgroundColor("BLUE")
                        .build();
                clevertapDefaultInstance.promptPushPrimer(jsonObject);
            }
        });
    }
}